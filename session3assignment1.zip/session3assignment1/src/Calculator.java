public class Calculator {
	public static void main(String args[])
	{
double i=25d,j=27d;
		double sqrt=Math.sqrt(i);
		double cbrt=Math.cbrt(j);
		System.out.println(" sqrt of "+ i +"=" +sqrt);
		System.out.println(" cbrt of "+ j +"=" +cbrt);
	}
}
